# APEX-MD

A modular Node.js WhatsApp bot using Baileys.

## Included command areas

### Owner
setpp, ban, unban, resetanticall, anticall, autotyping, antidelete,
autoviewstatus, delete, block, mode, ping, prefix

### Group
aproveall, hidetag, welcome, tagall, antigroupmention, demote, join,
add, vcf, promote, antilink

### AI
gpt, gemini, chatbot, colopit, grok, bing

### Downloads
play, img, video, lyrics, apk, tiktok, youtube, instagram, facebook

### Pairing
pair, delpair

`xvideos` is intentionally not implemented in this starter build.

## Setup

1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Set `OWNER_NUMBER` to the bot owner's WhatsApp number in international format.
4. Run:

```bash
npm install
npm start
```

5. On first launch, enter the WhatsApp number requested by the terminal to receive a pairing code.
6. Keep the `session/` directory private.

## VPS with PM2

```bash
npm install -g pm2
pm2 start src/index.js --name apex-md
pm2 save
pm2 startup
```

## Important

Some commands require the bot to be a group admin. Some WhatsApp features and third-party download/AI services require APIs and may change over time. Add API credentials in `.env` before enabling those integrations.

Use the bot in accordance with WhatsApp's terms and applicable laws.
