const {
  jidFromNumber, isOwner, parseCommand, mention
} = require("./utils");
const config = require("./config");

const menus = {
  owner: [
    "setpp <reply to image>",
    "ban <number>",
    "unban <number>",
    "resetanticall",
    "anticall on|off [block|reject]",
    "autotyping on|off",
    "antidelete on|off",
    "autoviewstatus on|off",
    "delete <reply to message>",
    "block <number>",
    "mode private|public",
    "ping",
    "prefix <new-prefix>"
  ],
  group: [
    "aproveall",
    "hidetag on|off",
    "welcome on|off",
    "tagall [message]",
    "antigroupmention on|off [warn|kick|delete]",
    "demote @user",
    "join <group link>",
    "add <number>",
    "vcf",
    "promote @user",
    "antilink on|off [delete|warn|kick]"
  ],
  ai: [
    "gpt <question>",
    "gemini <question>",
    "chatbot <question>",
    "colopit <question>",
    "grok <question>",
    "bing <question>"
  ],
  download: [
    "play <song name>",
    "img <prompt>",
    "video <url>",
    "lyrics <song>",
    "apk <Play Store URL>",
    "tiktok <url>",
    "youtube <name/url>",
    "instagram <url>",
    "facebook <url>"
  ],
  pairing: [
    "pair <number>",
    "delpair <number>"
  ]
};

function menuText(title, list, prefix) {
  return `╭━━━〔 ${title} 〕━━━╮\n${list.map(x => `┃ ${prefix}${x}`).join("\n")}\n╰━━━━━━━━━━━━━━╯`;
}

function fullMenu() {
  const p = config.get("prefix") || ".";
  return [
    `╭━━━〔 ⚡ ${config.get("botName")} 〕━━━╮`,
    `┃ Prefix: ${p}`,
    `┃ Mode: ${config.get("mode")}`,
    "╰━━━━━━━━━━━━━━━━╯",
    menuText("OWNER", menus.owner, p),
    menuText("GROUP", menus.group, p),
    menuText("AI", menus.ai, p),
    menuText("DOWNLOAD", menus.download, p),
    menuText("PAIRING", menus.pairing, p)
  ].join("\n\n");
}

function parseMentionedJids(message) {
  const ctx = message?.extendedTextMessage?.contextInfo;
  return ctx?.mentionedJid || [];
}

async function requireOwner(sock, msg, reply) {
  if (!isOwner(msg.key.participant || msg.key.remoteJid)) {
    await reply("❌ Owner only.");
    return false;
  }
  return true;
}

async function requireGroup(msg, reply) {
  if (!msg.key.remoteJid?.endsWith("@g.us")) {
    await reply("❌ This command only works in groups.");
    return false;
  }
  return true;
}

async function getGroupMetadata(sock, jid) {
  return sock.groupMetadata(jid);
}

async function isBotAdmin(sock, jid) {
  const meta = await getGroupMetadata(sock, jid);
  const bot = meta.participants.find(p => p.id === sock.user.id);
  return !!bot && (bot.admin === "admin" || bot.admin === "superadmin");
}

async function isSenderAdmin(sock, jid, sender) {
  const meta = await getGroupMetadata(sock, jid);
  const p = meta.participants.find(x => x.id === sender);
  return !!p && (p.admin === "admin" || p.admin === "superadmin");
}

async function executeCommand(sock, msg, text) {
  const parsed = parseCommand(text);
  if (!parsed) return false;

  const { command, args } = parsed;
  const jid = msg.key.remoteJid;
  const sender = msg.key.participant || jid;
  const reply = (text) => sock.sendMessage(jid, { text }, { quoted: msg });

  if (config.get("banned").includes(sender.split("@")[0])) {
    await reply("🚫 You are banned from using APEX-MD.");
    return true;
  }

  if (config.get("mode") === "private" && !isOwner(sender) && jid.endsWith("@g.us")) {
    await reply("🔒 APEX-MD is currently in private mode.");
    return true;
  }

  if (command === "menu" || command === "help") {
    await reply(fullMenu());
    return true;
  }

  if (["ping", "p"].includes(command)) {
    const start = Date.now();
    await reply(`🏓 PONG\n⚡ Response: ${Date.now() - start}ms\n🤖 ${config.get("botName")}`);
    return true;
  }

  if (command === "about") {
    await reply(`⚡ ${config.get("botName")}\nNode.js WhatsApp bot\nMode: ${config.get("mode")}\nPrefix: ${config.get("prefix")}`);
    return true;
  }

  if (command === "owner") {
    await reply(`👑 Owner: ${process.env.OWNER_NAME || "Owner"}\n📱 ${process.env.OWNER_NUMBER || "Not configured"}`);
    return true;
  }

  // OWNER COMMANDS
  if (["setpp","ban","unban","resetanticall","anticall","autotyping","antidelete",
       "autoviewstatus","delete","block","mode","prefix"].includes(command)) {
    if (!(await requireOwner(sock, msg, reply))) return true;

    if (command === "ban") {
      if (!args[0]) return reply(`Usage: ${parsed.prefix}ban 2547xxxxxxxx`);
      const n = args[0].replace(/\D/g, "");
      const list = config.get("banned");
      if (!list.includes(n)) list.push(n);
      config.set("banned", list);
      return reply(`🚫 Banned: ${n}`);
    }

    if (command === "unban") {
      if (!args[0]) return reply(`Usage: ${parsed.prefix}unban 2547xxxxxxxx`);
      const n = args[0].replace(/\D/g, "");
      config.set("banned", config.get("banned").filter(x => x !== n));
      return reply(`✅ Unbanned: ${n}`);
    }

    if (command === "resetanticall") {
      config.set("antiCallAction", "reject");
      config.set("antiCall", false);
      return reply("☎️ Anticall reset to OFF / reject.");
    }

    if (command === "anticall") {
      const on = (args[0] || "").toLowerCase();
      if (!["on","off"].includes(on)) return reply(`Usage: ${parsed.prefix}anticall on|off [block|reject]`);
      config.set("antiCall", on === "on");
      if (args[1] && ["block","reject"].includes(args[1].toLowerCase())) config.set("antiCallAction", args[1].toLowerCase());
      return reply(`☎️ Anticall: ${on.toUpperCase()} (${config.get("antiCallAction")})`);
    }

    if (["autotyping","antidelete","autoviewstatus"].includes(command)) {
      const on = (args[0] || "").toLowerCase();
      if (!["on","off"].includes(on)) return reply(`Usage: ${parsed.prefix}${command} on|off`);
      const key = command === "autotyping" ? "autoTyping" : command === "antidelete" ? "antiDelete" : "autoViewStatus";
      config.set(key, on === "on");
      return reply(`✅ ${command}: ${on.toUpperCase()}`);
    }

    if (command === "mode") {
      const mode = (args[0] || "").toLowerCase();
      if (!["private","public"].includes(mode)) return reply(`Usage: ${parsed.prefix}mode private|public`);
      config.set("mode", mode);
      return reply(`🔐 Mode set to ${mode}.`);
    }

    if (command === "prefix") {
      if (!args[0]) return reply(`Current prefix: ${config.get("prefix")}`);
      config.set("prefix", args[0].slice(0, 3));
      return reply(`✅ Prefix changed to: ${config.get("prefix")}`);
    }

    if (command === "setpp") {
      const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      const image = quoted?.imageMessage;
      if (!image) return reply(`Reply to an image with ${parsed.prefix}setpp.`);
      return reply("🖼️ Set profile picture requires downloading the quoted media; this handler is prepared for that integration.");
    }

    if (command === "delete") {
      const ctx = msg.message?.extendedTextMessage?.contextInfo;
      if (!ctx?.stanzaId) return reply(`Reply to a message with ${parsed.prefix}delete.`);
      try {
        await sock.sendMessage(jid, { delete: { remoteJid: jid, fromMe: ctx.participant === sock.user.id, id: ctx.stanzaId, participant: ctx.participant } });
        return true;
      } catch {
        return reply("❌ WhatsApp did not allow deletion of that message.");
      }
    }

    if (command === "block") {
      if (!args[0]) return reply(`Usage: ${parsed.prefix}block 2547xxxxxxxx`);
      const target = jidFromNumber(args[0]);
      await sock.updateBlockStatus(target, "block");
      return reply(`🚫 Blocked ${args[0]}`);
    }
  }

  // GROUP COMMANDS
  if (["aproveall","hidetag","welcome","tagall","antigroupmention","demote","join","add","vcf","promote","antilink"].includes(command)) {
    if (!(await requireGroup(msg, reply))) return true;
    const adminNeeded = ["aproveall","hidetag","welcome","tagall","antigroupmention","demote","add","vcf","promote","antilink"].includes(command);
    if (adminNeeded && !isOwner(sender) && !(await isSenderAdmin(sock, jid, sender))) {
      await reply("❌ Group admins only.");
      return true;
    }

    if (["demote","promote","add","aproveall"].includes(command) && !(await isBotAdmin(sock, jid))) {
      await reply("❌ I need to be a group admin first.");
      return true;
    }

    const mentions = parseMentionedJids(msg.message);

    if (command === "tagall") {
      const meta = await getGroupMetadata(sock, jid);
      const textMsg = args.join(" ") || "Attention everyone!";
      const ids = meta.participants.map(p => p.id);
      await sock.sendMessage(jid, { text: `📢 ${textMsg}\n\n${ids.map(mention).join(" ")}`, mentions: ids }, { quoted: msg });
      return true;
    }

    if (command === "hidetag") {
      const on = (args[0] || "").toLowerCase();
      config.set("hideTag", on === "on");
      return reply(`🏷️ Hidetag: ${on.toUpperCase()}`);
    }

    if (command === "welcome") {
      const on = (args[0] || "").toLowerCase();
      config.set("welcome", on === "on");
      return reply(`👋 Welcome: ${on.toUpperCase()}`);
    }

    if (command === "antilink") {
      const on = (args[0] || "").toLowerCase();
      if (!["on","off"].includes(on)) return reply(`Usage: ${parsed.prefix}antilink on|off [delete|warn|kick]`);
      config.set("antiLink", on === "on");
      if (args[1] && ["delete","warn","kick"].includes(args[1])) config.set("antiLinkAction", args[1]);
      return reply(`🔗 Antilink: ${on.toUpperCase()} (${config.get("antiLinkAction")})`);
    }

    if (command === "antigroupmention") {
      const on = (args[0] || "").toLowerCase();
      if (!["on","off"].includes(on)) return reply(`Usage: ${parsed.prefix}antigroupmention on|off [warn|kick|delete]`);
      config.set("antiGroupMention", on === "on");
      if (args[1] && ["warn","kick","delete"].includes(args[1])) config.set("antiGroupMentionAction", args[1]);
      return reply(`📣 Anti-group-mention: ${on.toUpperCase()}`);
    }

    if (command === "promote" || command === "demote") {
      const targets = mentions.length ? mentions : (args[0] ? [jidFromNumber(args[0])] : []);
      if (!targets.length) return reply(`Mention a user or provide a number.`);
      await sock.groupParticipantsUpdate(jid, targets, command);
      return reply(`✅ ${command} completed.`);
    }

    if (command === "add") {
      if (!args[0]) return reply(`Usage: ${parsed.prefix}add 2547xxxxxxxx`);
      await sock.groupParticipantsUpdate(jid, [jidFromNumber(args[0])], "add");
      return reply("✅ Add request sent.");
    }

    if (command === "aproveall") {
      try {
        const pending = await sock.groupRequestParticipantsList(jid);
        if (!pending?.length) return reply("ℹ️ No pending member requests.");
        await sock.groupRequestParticipantsUpdate(jid, pending.map(x => x.jid || x.id), "approve");
        return reply(`✅ Approved ${pending.length} member request(s).`);
      } catch {
        return reply("❌ This WhatsApp account/library does not expose member-request approval for this group.");
      }
    }

    if (command === "vcf") {
      const meta = await getGroupMetadata(sock, jid);
      const lines = meta.participants.map((p, i) => `BEGIN:VCARD\nVERSION:3.0\nFN:APEX Group Member ${i+1}\nTEL:+${p.id.split("@")[0].split(":")[0]}\nEND:VCARD`).join("\n");
      return sock.sendMessage(jid, { document: Buffer.from(lines), mimetype: "text/vcard", fileName: "apex-group-contacts.vcf", caption: "📇 Group contacts" }, { quoted: msg });
    }

    if (command === "join") {
      const link = args[0];
      const code = link?.match(/chat\.whatsapp\.com\/([A-Za-z0-9]+)/)?.[1];
      if (!code) return reply(`Usage: ${parsed.prefix}join https://chat.whatsapp.com/xxxxx`);
      try {
        const result = await sock.groupAcceptInvite(code);
        return reply(`✅ Joined group: ${result}`);
      } catch {
        return reply("❌ Could not join the group.");
      }
    }
  }

  // AI / DOWNLOAD placeholders
  const aiCommands = ["gpt","gemini","chatbot","colopit","grok","bing"];
  const dlCommands = ["play","img","video","lyrics","apk","tiktok","youtube","instagram","facebook"];

  if (aiCommands.includes(command)) {
    const q = args.join(" ");
    if (!q) return reply(`Usage: ${parsed.prefix}${command} your question`);
    return reply(`🤖 ${command.toUpperCase()} integration is ready for an API/provider.\n\nYour request:\n${q}\n\nAdd the provider API in src/providers/ to enable live responses.`);
  }

  if (dlCommands.includes(command)) {
    const q = args.join(" ");
    if (!q) return reply(`Usage: ${parsed.prefix}${command} name or URL`);
    return reply(`⬇️ ${command.toUpperCase()} provider integration is ready to be connected.\n\nRequest: ${q}`);
  }

  if (command === "pair") {
    if (!isOwner(sender)) return reply("❌ Owner only.");
    if (!args[0]) return reply(`Usage: ${parsed.prefix}pair 2547xxxxxxxx`);
    return reply("🔢 Pairing manager placeholder. Multi-number pairing should be connected to a dedicated session manager before production use.");
  }

  if (command === "delpair") {
    if (!isOwner(sender)) return reply("❌ Owner only.");
    if (!args[0]) return reply(`Usage: ${parsed.prefix}delpair 2547xxxxxxxx`);
    return reply(`🗑️ Pairing session removal requested for ${args[0]}. Connect this to your multi-session store.`);
  }

  return false;
}

module.exports = { executeCommand, fullMenu };
