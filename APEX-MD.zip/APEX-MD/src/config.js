require("dotenv").config();

const fs = require("fs");
const path = require("path");

const dataDir = path.join(process.cwd(), "data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const file = path.join(dataDir, "settings.json");

const defaults = {
  prefix: process.env.PREFIX || ".",
  mode: process.env.MODE || "private",
  antiCall: false,
  antiCallAction: "reject",
  autoTyping: false,
  antiDelete: false,
  autoViewStatus: false,
  welcome: false,
  antiLink: false,
  antiLinkAction: "delete",
  antiGroupMention: false,
  antiGroupMentionAction: "warn",
  hideTag: false,
  banned: [],
  botName: process.env.BOT_NAME || "APEX-MD"
};

function load() {
  try {
    if (fs.existsSync(file)) return { ...defaults, ...JSON.parse(fs.readFileSync(file, "utf8")) };
  } catch {}
  return { ...defaults };
}

let settings = load();

function save() {
  fs.writeFileSync(file, JSON.stringify(settings, null, 2));
}

function get(key) {
  return settings[key];
}

function set(key, value) {
  settings[key] = value;
  save();
}

module.exports = { settings, get, set, save };
