const config = require("./config");

function normalizeNumber(n) {
  return String(n || "").replace(/[^0-9]/g, "");
}

function jidFromNumber(n) {
  return normalizeNumber(n) + "@s.whatsapp.net";
}

function isOwner(sender) {
  const owner = normalizeNumber(process.env.OWNER_NUMBER);
  const number = normalizeNumber(sender?.split("@")[0]);
  return !!owner && owner === number;
}

function getPrefix(text) {
  const p = config.get("prefix") || ".";
  return text.startsWith(p) ? p : null;
}

function parseCommand(text) {
  const p = getPrefix(text);
  if (!p) return null;
  const body = text.slice(p.length).trim();
  const [command, ...args] = body.split(/\s+/);
  return { prefix: p, command: (command || "").toLowerCase(), args, text: args.join(" ") };
}

function mention(jid) {
  return `@${jid.split("@")[0]}`;
}

module.exports = { normalizeNumber, jidFromNumber, isOwner, getPrefix, parseCommand, mention };
