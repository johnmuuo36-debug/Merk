# Providers

Put external AI/download integrations here.

Recommended pattern:
- one provider module per service
- keep API keys in `.env`
- validate URLs and user input
- return a consistent `{ ok, text, media }` object

The starter bot intentionally does not scrape or bypass third-party services.
