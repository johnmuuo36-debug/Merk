const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  makeCacheableSignalKeyStore,
  fetchLatestBaileysVersion
} = require("@whiskeysockets/baileys");
const P = require("pino");
const readline = require("readline");
const { executeCommand } = require("./commands");
const config = require("./config");
const store = require("./store");

const logger = P({ level: "silent" });

async function ask(question) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise(resolve => rl.question(question, answer => {
    rl.close();
    resolve(answer.trim());
  }));
}

async function start() {
  const { state, saveCreds } = await useMultiFileAuthState("./session");

  let version;
  try {
    ({ version } = await fetchLatestBaileysVersion());
  } catch {
    version = undefined;
  }

  const sock = makeWASocket({
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, logger)
    },
    version,
    logger,
    printQRInTerminal: false,
    browser: ["APEX-MD", "Chrome", "1.0.0"],
    markOnlineOnConnect: false
  });

  if (!sock.authState?.creds?.registered) {
    const number = await ask("Enter WhatsApp number in international format (example 2547xxxxxxxx): ");
    const clean = number.replace(/\D/g, "");
    if (!clean) throw new Error("Invalid phone number.");

    try {
      const code = await sock.requestPairingCode(clean);
      console.log("\n================================");
      console.log("      APEX-MD PAIRING CODE");
      console.log("================================");
      console.log(code);
      console.log("Enter this code in WhatsApp > Linked devices.");
      console.log("================================\n");
    } catch (e) {
      console.error("Pairing failed:", e.message);
    }
  }

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
    if (connection === "open") {
      console.log("✅ APEX-MD connected.");
      console.log(`Prefix: ${config.get("prefix")} | Mode: ${config.get("mode")}`);
    }

    if (connection === "close") {
      const code = lastDisconnect?.error?.output?.statusCode;
      const shouldReconnect = code !== DisconnectReason.loggedOut;
      console.log("Connection closed.", shouldReconnect ? "Reconnecting..." : "Logged out.");
      if (shouldReconnect) setTimeout(start, 3000);
    }
  });

  sock.ev.on("messages.upsert", async ({ messages }) => {
    const msg = messages?.[0];
    if (!msg?.message || msg.key.fromMe) return;

    const jid = msg.key.remoteJid;
    const text =
      msg.message.conversation ||
      msg.message.extendedTextMessage?.text ||
      msg.message.imageMessage?.caption ||
      msg.message.videoMessage?.caption ||
      "";

    if (config.get("antiDelete")) {
      store.remember(msg.key.id, { jid, text, sender: msg.key.participant || jid });
    }

    if (config.get("autoTyping")) {
      try { await sock.sendPresenceUpdate("composing", jid); } catch {}
    }

    try {
      await executeCommand(sock, msg, text);
    } catch (err) {
      console.error("Command error:", err);
      try { await sock.sendMessage(jid, { text: "❌ An error occurred while processing that command." }, { quoted: msg }); } catch {}
    }
  });

  sock.ev.on("call", async calls => {
    if (!config.get("antiCall")) return;
    for (const call of calls) {
      if (call.status !== "offer") continue;
      try {
        if (config.get("antiCallAction") === "block") {
          await sock.updateBlockStatus(call.from, "block");
        } else {
          await sock.rejectCall(call.id, call.from);
        }
      } catch {}
    }
  });

  sock.ev.on("group-participants.update", async update => {
    if (!config.get("welcome")) return;
    if (update.action !== "add") return;
    const text = update.participants.map(x => `👋 Welcome ${x.split("@")[0]} to the group!`).join("\n");
    try { await sock.sendMessage(update.id, { text }); } catch {}
  });

  return sock;
}

start().catch(err => {
  console.error(err);
  process.exit(1);
});
