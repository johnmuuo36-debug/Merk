const fs = require("fs");
const path = require("path");

const dir = path.join(process.cwd(), "data");
const file = path.join(dir, "messages.json");
if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

let messages = {};
try { messages = JSON.parse(fs.readFileSync(file, "utf8")); } catch {}

function save() {
  fs.writeFileSync(file, JSON.stringify(messages, null, 2));
}

function remember(key, msg) {
  messages[key] = msg;
  const keys = Object.keys(messages);
  if (keys.length > 500) delete messages[keys[0]];
  save();
}

function get(key) { return messages[key]; }

module.exports = { remember, get };
